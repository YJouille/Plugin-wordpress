<?php
echo 'page admin';
?>