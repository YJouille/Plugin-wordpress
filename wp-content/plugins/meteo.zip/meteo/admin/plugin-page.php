<?php
require_once  __DIR__ . '/../Models/Data.php'; 
require_once  __DIR__ . '/../Controllers/meteoController.php'; 

?>

<div class="wrap">
	<!-- <div id="icon-options-general" class="icon32"></div> -->
	<h1>Plugin Météo</h1>
	<form method="post" action="options.php">
                <?php

    // add_settings_section callback is displayed here. For every new section we need to call settings_fields.
    settings_fields("option_section");

    // all the add_settings_field callbacks is displayed here
    do_settings_sections("theme-options");

    // Add the submit button to serialize the options
    submit_button();

    ?>         
            </form>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
<br>
<br>

<h3>Enregistrement d'une clé d'API open weather map </h3>
    <form method="POST" action=''>  
        <div class="form-row align-items-center">
            <div class="col-auto my-1">               
                <input type="text" name="APIKey" value="<?php  ?>">               
            </div>

            <div class="col-auto my-1">
                <button type="submit" class="btn btn-primary" name="save-api" value="save-api">Enregistrer</button>
            </div>
        </div>
    </form>
      
    <?php
    if (isset($_POST['APIKey']) ) {
        saveAPIKey();
    }
    ?>

    