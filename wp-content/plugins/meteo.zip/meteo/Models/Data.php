<?php



class Data 
{   
    public function saveAPIKeyData(){
        global $wpdb; 
        $apiKey =  $_POST['APIKey'];
        $sql = "INSERT INTO ".$wpdb->prefix."options(option_name, option_value, autoload )VALUES ('APIKey','".$apiKey."','yes')" ;
        $wpdb->query($sql);
    }
}

