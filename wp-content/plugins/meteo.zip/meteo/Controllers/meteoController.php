<?php
require_once  __DIR__ . '/../Models/Data.php';

$data = new Data();

 function saveAPIKey(){
     global $data;
     $data->saveAPIKeyData();
 }